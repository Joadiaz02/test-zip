
package spacex;

public interface CantListosParaLanzar {
    
    
    boolean listosParaLanzar();
    
    
}
