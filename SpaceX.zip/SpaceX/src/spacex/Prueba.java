
package spacex;

public abstract class Prueba implements CantListosParaLanzar {
    private String fechaDePrueba;
    
    
    public Prueba(String fechaDePrueba){
    this.fechaDePrueba = fechaDePrueba;
    }

    
}
