package spacex;

public class SpaceXtest {

  
    public static void main(String[] args) {
              SpaceX agencia = new SpaceX();
        
        cargarAgenciaEspacial(agencia);
        
        System.out.println(agencia.cohetesAprobados());

    }
        public static void cargarAgenciaEspacial(SpaceX agencia) {

        Cohete dragon = new Cohete(1234, "Dragon");
        Cohete starship = new Cohete(2222, "Starship");
        Cohete falcon1 = new Cohete(3333, "Falcon 1");
        Cohete falcon9 = new Cohete(4444, "Falcon 2");
        Cohete falconHeavy = new Cohete(5555, "Heavy");
        
        try{
        starship.agregarPrueba(new PruebaPropulsion("2024", 80, 7));
        starship.agregarPrueba(new PruebaPropulsion("2024", 80, 6));
        starship.agregarPrueba(new PruebaPropulsion("2024", 80, 7));
        starship.agregarPrueba(new PruebaPropulsion("2024", 80, 7));
        starship.agregarPrueba(new PruebaSistema("2023", Nivel.ACEPTABLE));
        starship.agregarPrueba(new PruebaSistema("2023", Nivel.EXCELENTE));
        starship.agregarPrueba(new PruebaPropulsion("2024", 80, 7));
        
        dragon.agregarPrueba(new PruebaPropulsion("2024", 80, 9));
        dragon.agregarPrueba(new PruebaPropulsion("2024", 80, 7));
        dragon.agregarPrueba(new PruebaPropulsion("2024", 80, 7));
        dragon.agregarPrueba(new PruebaSistema("2023", Nivel.ACEPTABLE));
        dragon.agregarPrueba(new PruebaSistema("2023", Nivel.EXCELENTE));
        } catch (NullPointerException e){
            System.out.println(e.getMessage());
        }
        agencia.agregarCohete(dragon);
        agencia.agregarCohete(starship);        
        
    }

}
