
package spacex;

import java.util.ArrayList;
import java.util.List;


public class Cohete implements CantListosParaLanzar {
    private int id;
    private String nombre;
    
    private List<Prueba> pruebas;
    
    
    public Cohete(int id, String nombre){
    this.id = id;
    this.nombre= nombre;
    pruebas = new ArrayList<>();
    }
    
    public void agregarPrueba(Prueba prueba){
    
        if(prueba == null){
            throw new NullPointerException("No se recibio ninguna prueba");
        }
        pruebas.add(prueba);
    }
    
    @Override
    public boolean listosParaLanzar(){
        int i = 0;
        while (i < pruebas.size() && pruebas.get(i).listosParaLanzar()) {
            i++;
        }
        return i == pruebas.size();

    }
}
    
    

