
package spacex;

import java.util.ArrayList;

public class SpaceX {
    
    private ArrayList<Cohete> cohetes = new ArrayList<>();
    public SpaceX(){
    
    
    }
 
    public void agregarCohete(Cohete cohete) {
        if (cohete != null) {
            cohetes.add(cohete);
        }
    }

    public int cohetesAprobados() {
        int cantidad = 0;
        for (Cohete cohete : cohetes) {
            if (cohete.listosParaLanzar()) {
                cantidad++;
            }
        }
        return cantidad;
    }

    

    
}
