
package spacex;

public class PruebaPropulsion extends Prueba implements CantListosParaLanzar {
   private int duracion;
   private int puntaje;
   private static final int MIN_PUNTAJE = 0;
   private static final int MAX_PUNTAJE = 10;
   private static final int PUNTAJE_APROB = 6;
   private static final int MIN_DURACION = 90;

    public PruebaPropulsion(String fechaDePrueba,int duracion, int puntaje ){
    super(fechaDePrueba);
    setPuntaje(puntaje);
    this.duracion = duracion;
    }
    
    public void setPuntaje(int puntaje) {
        if (puntaje < 0 || puntaje > 10) {
            throw new IllegalArgumentException("El puntaje debe estar entre 0 y 10.");
        }
        this.puntaje = puntaje;
    }
    
    @Override
    public boolean listosParaLanzar(){
    return puntaje >= PUNTAJE_APROB && duracion < MIN_DURACION;
    
    }
    
}
