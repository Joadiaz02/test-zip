
package spacex;


public class PruebaSistema extends Prueba implements CantListosParaLanzar{
    private Nivel nivelPrueba;
    
    public PruebaSistema(String fechaDePrueba, Nivel nivelPrueba ){
    super(fechaDePrueba);
    this.nivelPrueba = nivelPrueba;
    
    }
    
    @Override
    public boolean listosParaLanzar(){
    return nivelPrueba.ordinal() >= Nivel.ACEPTABLE.ordinal();
    }
     
    
}
