
package spacex;

public enum Nivel {
    DEFICIENTE,
    ACEPTABLE,
    EXCELENTE
}
